document.addEventListener('DOMContentLoaded', function () {
    // Smooth scrolling for navigation links
    const links = document.querySelectorAll('#sidebar ul li a');

    links.forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault();

            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);

            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 20, // Adjust to account for fixed sidebar
                    behavior: 'smooth'
                });
            }
        });
    });

    // Update the footer with the current year
    const footerYear = document.querySelector('footer p');
    const currentYear = new Date().getFullYear();
    footerYear.textContent = `© ${currentYear} Shrey Gupta. All rights reserved.`;
});
