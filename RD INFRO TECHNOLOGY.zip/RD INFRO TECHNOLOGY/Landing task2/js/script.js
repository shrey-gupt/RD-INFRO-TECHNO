// JavaScript for Adidas Landing Page

// Toggle Mobile Navigation
const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('nav ul');

navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('nav-open');
});

// Interactive Dashboard - Simulated Data and Interactivity
document.addEventListener('DOMContentLoaded', () => {
    // Simulate fetching sales data
    const salesData = [
        { month: 'January', sales: 120 },
        { month: 'February', sales: 150 },
        { month: 'March', sales: 180 },
        { month: 'April', sales: 130 },
        { month: 'May', sales: 170 },
        { month: 'June', sales: 160 },
    ];

    const salesContainer = document.querySelector('.dashboard-item.sales .data');
    salesData.forEach(data => {
        const dataItem = document.createElement('p');
        dataItem.textContent = `${data.month}: ${data.sales} sales`;
        salesContainer.appendChild(dataItem);
    });

    // Simulate fetching product launch data
    const launchData = [
        { product: 'New Running Shoes', date: '2024-01-15' },
        { product: 'Winter Jacket', date: '2024-02-10' },
        { product: 'Summer Collection', date: '2024-03-25' },
    ];

    const launchContainer = document.querySelector('.dashboard-item.launches .data');
    launchData.forEach(data => {
        const dataItem = document.createElement('p');
        dataItem.textContent = `${data.product}: ${data.date}`;
        launchContainer.appendChild(dataItem);
    });

    // Simulate fetching customer feedback
    const feedbackData = [
        { name: 'John Doe', feedback: 'Great quality products!' },
        { name: 'Jane Smith', feedback: 'Excellent customer service.' },
        { name: 'Mike Johnson', feedback: 'Fast delivery, very satisfied.' },
    ];

    const feedbackContainer = document.querySelector('.dashboard-item.feedback .data');
    feedbackData.forEach(data => {
        const dataItem = document.createElement('p');
        dataItem.textContent = `${data.name}: ${data.feedback}`;
        feedbackContainer.appendChild(dataItem);
    });
});
